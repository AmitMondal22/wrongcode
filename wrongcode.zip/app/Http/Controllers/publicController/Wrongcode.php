<?php

namespace App\Http\Controllers\publicController;

use App\Http\Controllers\Controller;
use App\Models\WcContact;
use App\Rules\ReCaptcha;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class Wrongcode extends Controller
{
    public function index(){
        return view('wrongcode.index');
    }
    public function contuct_data(Request $r){
        $validator = Validator::make($r->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'subject' => 'required|string|max:255',
            'message' => 'required|string',
            'g-recaptcha-response' => ['required', new ReCaptcha]
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 400);
        }

        WcContact::create([
            "name"=>$r->name,
            "email"=>$r->email,
            "subject"=>$r->subject,
            "message"=>$r->message
        ]);

        return redirect()->route('root');
    }
}
