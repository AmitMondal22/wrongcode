<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="WrongCode is a IT Company portfolio with clean and elegant design">
    <meta name="keywords" content="Wrong Code,WrongCode,wrongCode,wrongcode,WRONGCODE Wrongcode,Wrong code,portfolio">
    <title>WrongCode</title>
    <!--css styles-->
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/lightbox.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/owl.carousel.css">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/owl.theme.css">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/slicknav.min.css">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/reset.css">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/style.css">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/responsive.css">
    <link rel="stylesheet" href="{{ asset('wrongcode') }}/css/animate.min.css">
    <!---title logo icon-->
    <link rel="shortcut icon" href="{{ asset('wrongcode') }}/images/favicon.png" />

    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/respond.js"></script>

    <script src='https://www.google.com/recaptcha/api.js'></script>


    <!-- tostar -->
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">


</head>

<body class="scroll">
    <!-- Start Preloader -->
    <div class="preloader">
        <div class="preloader-img"></div>
    </div>
    <!-- End Preloader -->

    <!-- Start scroll-top button -->
    <div id="scroll-top-area">
        <a href="#welcome-area"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
    </div>
    <!-- End scroll-top button -->

    @include("wrongcode.common.htader")

    @yield('content')




    @include('wrongcode.common.footer')

    <script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
        <script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
        {!! Toastr::message() !!}
    <!--javascript-->
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/jquery.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/particles.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/jquery.slicknav.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/mixitup.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/typed.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/lightbox.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/particlesReset.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/jquery.waypoints.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/jquery.counterup.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/jquery.stellar.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/jquery.singlePageNav.min.js"></script>
    <script type="text/javascript" src="{{ asset('wrongcode') }}/js/main.js"></script>


    @yield('script')


</body>
</html>
