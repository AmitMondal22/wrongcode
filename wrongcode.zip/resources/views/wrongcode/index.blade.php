@extends('wrongcode.common.layout')
@section('content')


<!--Start Welcome Section-->
<section class="welcome-area particle-bg" id="welcome-area" data-stellar-background-ratio="0.2" data-stellar-vertical-offset="0">
        <div id="particles-js"></div>
        <div class="welcome-text">
            <h6>WrongCode provides a dynamic blend of strategy </br>
                consulting and systems integration services to help</br>
                companies shape and build their businesses in the economy</h6>
            <div class="element"></div>
            <a href="#" class="btn-style2 skill-btn">SEE OUR WORKS</a>
        </div>
    </section>
    <!--End Welcome Section-->



    <!--Start About Section-->
    <section class="about padding-style1" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-4">
                    <div class="about-img">
                        <img src="{{ asset('wrongcode') }}/images/about.jpg" alt="" class="about-img img-responsive">
                        <div class="about-img-overlay">
                            <div class="social-icons">
                                <a href="https://www.facebook.com/WrongCode.in"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-8">
                    <div class="about-text">
                        <h4 class="section-title">
                            ABOUT US
                        </h4>
                        <p>
                            Welcome to our software development company! We are a dynamic team of talented software engineers, designers and project managers who are passionate about developing innovative and impactful solutions for our clients. With years of industry experience and a proven track record of delivering successful projects, we are dedicated to providing world-class software development services tailored to your unique business needs.
                        </p>
                        <p>

                            <b>Our Mission:</b> <br>
                            At WrongCode, our mission is to empower businesses by leveraging the latest technologies and industry best practices. We strive to deliver innovative software solutions that optimize efficiency, increase productivity, and drive business growth. We are committed to building long-term partnerships with our customers and helping them stay ahead in today's competitive digital landscape.
                            <!-- <a href="#">DOWNLOAD MY CV<i class="fa fa-download" aria-hidden="true"></i> -->
                        </p>
                        <p><b>Expertise and Specializations:</b> <br>
                            With a wide range of skills and expertise, our team excels in developing custom software solutions for various industries. From web applications to mobile apps to enterprise software, we have the knowledge and experience to tackle complex projects of any scale. Our technical expertise includes the following areas, among others:
                            <li>Full-stack web development (HTML/CSS, JavaScript, Python, Angular, React, NodeJS, )</li>
                            <li>Mobile application development (iOS, Android, React Native)</li>
                            <li>Database design and management (SQL, NoSQL)</li>
                            <li>Cloud computing and deployment (AWS, Google Cloud)</li>
                            <li>User experience design (UX) and user interface development (UI)</li>
                            <br>
                            Agile project management methods
                        </p>

                    </div>
                </div>
                <div class="fun-info">
                    <div class="row">
                        <div class="col-md-3 col-sm-6">
                            <div class="fun-item">
                                <i class="fa fa-trophy" aria-hidden="true"></i>
                                <div class="fun-fact">
                                    <h4 class="counter">150</h4>
                                    <p>PSD to HTML</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="fun-item">
                                <i class="fa fa-diamond" aria-hidden="true"></i>
                                <div class="fun-fact">
                                    <h4 class="counter">56</h4>
                                    <p>Projects</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="fun-item">
                                <i class="fa fa-coffee" aria-hidden="true"></i>
                                <div class="fun-fact">
                                    <h4 class="counter">101</h4>
                                    <p>Cups of Tea</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="fun-item">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <div class="fun-fact">
                                    <h4 class="counter">48</h4>
                                    <p>Clients</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section-->

    <!--Start Services Section-->
    <section class="services padding-style1" id="services">
        <div class="services-header">
            <h4 class="section-title">SERVICES I OFFER</h4>
        </div>
        <div class="services-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="service-item animation" data-animation="fadeInUp">
                            <div class="service-content scroll">
                                <span><i class="fa fa-cube" aria-hidden="true"></i></span>
                                <p class="content-title">WEB DESIGN</p>
                                <p class="content-text">WrongCode is a leading web design and mobile app design agency with a knack for turning great ideas into meaningful interactions. We get creative and you get noticed. One-page or sales page, static or dynamic, mobile app or responsive, logo, banner/any design, you get every design with quality and uniqueness. PSD to any HTML or CMS, Responsive, creating beautiful websites with state of the art functionality.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="service-item animation" data-animation="fadeInUp">
                            <div class="service-content scroll">
                                <span><i class="fa fa-wrench" aria-hidden="true"></i></span>
                                <p class="content-title">WEB DEVELOPMENT</p>
                                <p class="content-text">We offer a wide range of technologies to deliver the most reliable web application development solutions to our clients worldwide. WrongCode is a leading website application development company in India, offering cutting-edge technological solutions for next generation web applications</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="service-item animation" data-animation="fadeInUp">
                            <div class="service-content scroll">
                                <span><i class="fa fa-plug" aria-hidden="true"></i></span>
                                <p class="content-title">APP DEVELOPMENT</p>
                                <p class="content-text">Do you want to develop a robust and scalable mobile app? We are a leading mobile app development company offering customized mobile app development services based on your needs, budget and time.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 ">
                        <div class="service-item animation" data-animation="fadeInUp">
                            <div class="service-content scroll">
                                <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
                                <p class="content-title">DIGITAL MARKETING</p>
                                <p class="content-text">We enable global companies and businesses to achieve this through creative content, personalized campaign creation with management, and 360-degree online reputation management by leveraging our decades of experience in digital marketing services</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Services Section-->


    <!--Start Portfolio Section-->
    <section class="portfolio padding-style1" id="portfolio">
        <div class="portfolio-header">
            <h4 class="section-title">OUR WORKS</h4>
        </div>
        <div class="portfolio-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="portfolio-content-head">
                            <ul class="controls">
                                <li class="filter" data-filter="all">ALL</li>
                                <li class="filter" data-filter=".design">DESIGN</li>
                                <li class="filter" data-filter=".development">DEVELOPMENT</li>
                                <li class="filter" data-filter=".plugin">LOGO</li>
                                <li class="filter" data-filter=".photography">PHOTOGRAPHY</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs">
                        <div class="portfolio-content-items">
                            <div class="row">
                                <div class="col-md-4 col-sm-6 col-xs-12 mix design">
                                    <div class="portfolio-item">
                                        <div class="portfolio-img">
                                            <img src="{{ asset('wrongcode') }}/images/portfolio/img1.jpg" alt="portfolio" class="img-responsive">
                                        </div>
                                        <div class="portfolio-overlay">
                                            <div class="overlay-content">
                                                <p class="category">DESIGN</p>
                                                <a href="#">
                                                    <div class="magnify-icon">
                                                        <p><span><i class="fa fa-link" aria-hidden="true"></i></span></p>
                                                    </div>
                                                </a>
                                                <a href="{{ asset('wrongcode') }}/images/portfolio/img1.jpg" data-lightbox="image-1">
                                                    <div class="magnify-icon">
                                                        <p><span><i class="fa fa-search" aria-hidden="true"></i></span></p>
                                                    </div>
                                                </a>
                                                <div class="corner-top"></div>
                                                <div class="corner-bottom"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12 mix plugin">
                                    <div class="portfolio-item">
                                        <div class="portfolio-img">
                                            <img src="{{ asset('wrongcode') }}/images/portfolio/img2.jpg" alt="portfolio" class="img-responsive">
                                        </div>
                                        <div class="portfolio-overlay">
                                            <p class="category">LOGO</p>
                                            <a href="#">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-link" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <a href="{{ asset('wrongcode') }}/images/portfolio/img2.jpg" data-lightbox="image-2">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-search" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <div class="corner-top"></div>
                                            <div class="corner-bottom"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12 mix photography">
                                    <div class="portfolio-item">
                                        <div class="portfolio-img">
                                            <img src="{{ asset('wrongcode') }}/images/portfolio/img3.jpg" alt="portfolio" class="img-responsive">
                                        </div>
                                        <div class="portfolio-overlay">
                                            <p class="category">PHOTOGRAPHY</p>
                                            <a href="#">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-link" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <a href="{{ asset('wrongcode') }}/images/portfolio/img3.jpg" data-lightbox="image-3">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-search" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <div class="corner-top"></div>
                                            <div class="corner-bottom"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12 mix plugin">
                                    <div class="portfolio-item">
                                        <div class="portfolio-img">
                                            <img src="{{ asset('wrongcode') }}/images/portfolio/img4.jpg" alt="portfolio" class="img-responsive">
                                        </div>
                                        <div class="portfolio-overlay">
                                            <p class="category">LOGO</p>
                                            <a href="#">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-link" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <a href="{{ asset('wrongcode') }}/images/portfolio/img4.jpg" data-lightbox="image-4">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-search" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <div class="corner-top"></div>
                                            <div class="corner-bottom"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12 mix design">
                                    <div class="portfolio-item">
                                        <div class="portfolio-img">
                                            <img src="{{ asset('wrongcode') }}/images/portfolio/img5.jpg" alt="portfolio" class="img-responsive">
                                        </div>
                                        <div class="portfolio-overlay">
                                            <p class="category">DESIGN</p>
                                            <a href="#">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-link" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <a href="{{ asset('wrongcode') }}/images/portfolio/img5.jpg" data-lightbox="image-5">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-search" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <div class="corner-top"></div>
                                            <div class="corner-bottom"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12 mix development">
                                    <div class="portfolio-item">
                                        <div class="portfolio-img">
                                            <img src="{{ asset('wrongcode') }}/images/portfolio/img6.jpg" alt="portfolio" class="img-responsive">
                                        </div>
                                        <div class="portfolio-overlay">
                                            <p class="category">DEVELOPMENT</p>
                                            <a href="#">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-link" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <a href="{{ asset('wrongcode') }}/images/portfolio/img6.jpg" data-lightbox="image-6">
                                                <div class="magnify-icon">
                                                    <p><span><i class="fa fa-search" aria-hidden="true"></i></span></p>
                                                </div>
                                            </a>
                                            <div class="corner-top"></div>
                                            <div class="corner-bottom"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Portfolio Section-->

    <!--Start hire-me Section-->
    <section class="hire-me padding-style2" data-stellar-background-ratio="0.4" data-stellar-vertical-offset="90">
        <div class="container">
            <div class="col-md-10">
                <div class="hire-text animation" data-animation="slideInLeft">
                    <h4>Do you have an exciting idea for a project?</h4>
                    <p> Make your dream come true with your budget.</p>
                </div>
            </div>
            <div class="col-md-2">
                <a href="#" class="btn-style2 hire-btn animation" data-animation="slideInRight">Contact Us</a>
            </div>
        </div>
    </section>
    <!--End hire-me Section-->

    <!--Start Blog Section Area-->
    <section class="blog padding-style1" id="blog">
        <div class="blog-header">
            <h4 class="section-title">WATCH OUR BLOG</h4>
        </div>
        <div class="blog-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-single-item blog-item-margin">
                            <div class="blog-img">
                                <img src="{{ asset('wrongcode') }}/images/blog/blog-img1.jpg" alt="blog1" class="img-responsive">
                            </div>
                            <div class="blog-text">
                                <p class="blog-title">Nec scelerisque proin diam curabitur</p>
                                <p class="blog-description">Ac vestibulum in accumsan in curabitur ullam parturient ridiculus magna potenti et risus euismod adipiscing a....
                                </p>
                                <a href="#" class="read-more btn-style3">READ MORE</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-single-item blog-item-margin">
                            <div class="blog-img">
                                <img src="{{ asset('wrongcode') }}/images/blog/blog-img2.jpg" alt="blog2" class="img-responsive">
                            </div>
                            <div class="blog-text">
                                <p class="blog-title">Nec scelerisque proin diam curabitur</p>
                                <p class="blog-description">Ac vestibulum in accumsan in curabitur ullam parturient ridiculus magna potenti et risus euismod adipiscing a....
                                </p>
                                <a href="#" class="read-more btn-style3">READ MORE</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-single-item">
                            <div class="blog-img">
                                <img src="{{ asset('wrongcode') }}/images/blog/blog-img3.jpg" alt="blog3" class="img-responsive">
                            </div>
                            <div class="blog-text">
                                <p class="blog-title">Nec scelerisque proin diam curabitur</p>
                                <p class="blog-description">Ac vestibulum in accumsan in curabitur ullam parturient ridiculus magna potenti et risus euismod adipiscing a....
                                </p>
                                <a href="#" class="read-more btn-style3">READ MORE</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Blog Section Area-->

    <!--Start Client Testimonial Section Area-->
    <section class="client-testimonial" id="client-testimonial" data-stellar-background-ratio="0.4" data-stellar-vertical-offset="100">
        <div class="client-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <!--Start testimonial title area-->
                        <div class="testimonial-title text-center">
                            <h4 class="section-title">WHAT CLIENTS SAY</h4>
                        </div>
                        <!--End testimonial title area-->
                    </div>
                </div>
                <div class="row">
                    <div id="owl-demo-testimonial" class="owl-carousel owl-theme">
                        <!--Start Client Single design area-->
                        <div class="item">
                            <div class="client-img">
                                <img src="{{ asset('wrongcode') }}/images/client/img1.jpg" alt="client">
                            </div>
                            <div class="testimonial-content">
                                <div class="triangle"></div>
                                <div class="quote-text">
                                    <p>
                                        <i class="fa fa-quote-left" aria-hidden="true"></i>
                                        <span>Facilisis eu iaculis suspendisse congue auctor parturient consectetur nec gravida parturient turpis parturient a mi consectetur suscipit et porta.Molestie a ridiculus eu etiam.</span>
                                        <i class="fa fa-quote-right" aria-hidden="true"></i>
                                    </p>
                                    <div class="client-identity">
                                        <p class="name">OLIVER GOMEZ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Client Single design area-->
                        <!--Start Client Single design area-->
                        <div class="item">
                            <div class="client-img">
                                <img src="{{ asset('wrongcode') }}/images/client/img2.jpg" alt="client">
                            </div>
                            <div class="testimonial-content">
                                <div class="triangle"></div>
                                <div class="quote-text">
                                    <p>
                                        <i class="fa fa-quote-left" aria-hidden="true"></i>
                                        <span>Facilisis eu iaculis suspendisse congue auctor parturient consectetur nec gravida parturient turpis parturient a mi consectetur suscipit et porta.Molestie a ridiculus eu etiam.</span>
                                        <i class="fa fa-quote-right" aria-hidden="true"></i>
                                    </p>
                                    <div class="client-identity">
                                        <p class="name">SILVIA GOMEZ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Client Single design area-->
                        <!--Start Client Single design area-->
                        <div class="item">
                            <div class="client-img">
                                <img src="{{ asset('wrongcode') }}/images/client/img3.jpg" alt="client">
                            </div>
                            <div class="testimonial-content">
                                <div class="triangle"></div>
                                <div class="quote-text">
                                    <p>
                                        <i class="fa fa-quote-left" aria-hidden="true"></i>
                                        <span>Facilisis eu iaculis suspendisse congue auctor parturient consectetur nec gravida parturient turpis parturient a mi consectetur suscipit et porta.Molestie a ridiculus eu etiam.</span>
                                        <i class="fa fa-quote-right" aria-hidden="true"></i>
                                    </p>
                                    <div class="client-identity">
                                        <p class="name">JAMES GOMEZ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Client Single design area-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Client Testimonial Section Area-->

    <!--Start Contact Section-->
    <section class="contact padding-style1" id="contact">
        <div class="contact-header">
            <h4 class="section-title">GET IN TOUCH</h4>
        </div>
        <div class="contact-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <div class="contact-detail">
                            <h6 class="mini-header">Contact</h6>
                            <p>Tell us your business needs and we will be happy to assist you in making the right choice to find the best solution for you.<br>

                                Once all your needs and goals have been documented, we will provide you with a proposal for your project including a live demo of the solution.</p>
                            <div class="row contact-item">
                                <p class="adress col-md-6">
                                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                                    <span>Address:</span>Nandakumar, Purba Medinipur,721632.
                                </p>
                                <p class="phone col-md-6">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                    <span>Contact no:</span>+91 78908 33920
                                </p>
                                <p class="email col-md-6">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                    <span>Email:</span>info@wrongcode.in
                                </p>
                                <!-- <p class="web col-md-6">
                                    <i class="fa fa-globe" aria-hidden="true"></i>
                                    <span>Website:</span><a href="https://www.WrongCode.in">www.WrongCode.in</a>
                                </p> -->
                            </div>

                            <div class="social-icons">
                                <p>Find:</p>
                                <a href="https://www.facebook.com/WrongCode.in"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <form class="contact-form-area" method="post" action="{{route('contact')}}">
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" placeholder="Name" id="name" name="name" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="email" placeholder="Email" id="email" name="email" required>
                                </div>

                                <div class="col-md-12">
                                <input type="text" placeholder="subject" id="email" name="subject" required>
                                </div>

                                <div class="col-md-12">
                                    <textarea placeholder="Type here" id="message" name="message" required></textarea>

                                    <div class="result"></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="g-recaptcha" data-sitekey="{{ env('GOOGLE_RECAPTCHA_KEY') }}"></div>
                                        @if ($errors->has('g-recaptcha-response'))
                                            <span class="text-danger">{{ $errors->first('g-recaptcha-response') }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="submit" class="submit-btn btn-style1" value="SUBMIT" id="">
                                    <div class="result"></div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Contact Section-->



@endsection
@section('script')


@endsection
