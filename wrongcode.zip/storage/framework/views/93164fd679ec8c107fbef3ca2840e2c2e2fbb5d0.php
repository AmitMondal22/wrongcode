
    <!--Start Header-->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <a href="index.html" class="logo">
                        <img src="<?php echo e(asset('wrongcode')); ?>/images/logo.png" alt="logo" style="width: 250px;
                        height: 70px;">
                    </a>
                </div>
                <div class="col-md-9">
                    <nav class="menu single-page-nav" id="menu">
                        <ul>
                            <li><a class="home" href="#welcome-area">Home</a></li>
                            <li><a href="#about">About</a></li>
                            <li><a href="#services">Services</a></li>
                            <li><a href="#portfolio">Work</a></li>
                            <li><a href="#contact">Contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!--End Header-->
<?php /**PATH E:\LARAVEL\wrongcode\resources\views/wrongcode/common/htader.blade.php ENDPATH**/ ?>