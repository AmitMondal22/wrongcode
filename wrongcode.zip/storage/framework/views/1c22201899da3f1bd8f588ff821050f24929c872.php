

    <!--Start Footer-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright">
                        <p>Copyright © 2023 WrongCode | All rights reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--End Footer-->
<?php /**PATH E:\LARAVEL\wrongcode\resources\views/wrongcode/common/footer.blade.php ENDPATH**/ ?>